﻿using System;

namespace Domain_Layer
{
    public class Class1
    {
    }
}
