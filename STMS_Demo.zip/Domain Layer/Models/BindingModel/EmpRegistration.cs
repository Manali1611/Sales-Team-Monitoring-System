﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Models.BindingModel
{
    public partial class EmpRegistration
    {
        public EmpRegistration()
        {
            VisitTables = new HashSet<VisitTable>();
        }
        [Key]
        public int EmpId { get; set; }
        public string EmpFirstName { get; set; }
        public string EmpLastName { get; set; }
        public string EmpEmail { get; set; }
        public string EmpPassword { get; set; }
        public int EmpAge { get; set; }
        public string EmpGender { get; set; }
        public string EmpAddress { get; set; }
        public string EmpPhoneNo { get; set; }
        public string UseType { get; set; } = "User";

        public virtual ICollection<VisitTable> VisitTables { get; set; }

    }
}
