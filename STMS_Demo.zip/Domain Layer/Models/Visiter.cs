﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public class Visiter
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int visitId { get; set; }
        [Required]
        public string CustName { get; set; }
        [Required]
        public string ContactPerson { get; set; }
        [Required]
        public string ContactNo { get; set; }
        [Required]
        public string InterestProduct { get; set; }

        [Required]
        public string VisitSubject { get; set; }
        [Required]
        public string Description { get; set; }

        public DateTime dateTime { get; set; }

        public string IsDisabled { get; set; }

        public string IsDeleted { get; set; }
    }
}
