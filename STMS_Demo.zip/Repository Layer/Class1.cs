﻿using System;

namespace Repository_Layer
{
    public class Class1
    {
    }
}
