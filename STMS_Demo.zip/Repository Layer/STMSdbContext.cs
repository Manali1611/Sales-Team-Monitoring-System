﻿using System;
using DomainLayer.Models;
using DomainLayer.Models.BindingModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using RepositoryLayer.Entities;

#nullable disable

namespace STMS_Demo.Models
{
    public partial class STMSdbContext : IdentityDbContext<AppUser, IdentityRole, string>
    {




        public STMSdbContext(DbContextOptions<STMSdbContext> options): base(options)
        {
        }

        public DbSet<Visiter> visiters { get; set; }





    }
}
