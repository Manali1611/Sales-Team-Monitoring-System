﻿using DomainLayer.Models.BindingModel;
using RepositoryLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace ServiceLayer
{
   public interface IUser
    {
        //RegisterUser
        Task<object> RegisterUser([FromBody]EmpRegistration model);
        //GetAllUser
        Task<object> GetAllUsers();
        //Login
        Task<object> Login([FromBody]Login model);
        //AddRole
        Task<Object> AddRole([FromBody]Roles model);
        //GetRoles
        Task<object> GetRoles();
        //GenerateToken
        //string GenerateToken(AppUser user, string role);
    }
}
