﻿using DomainLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public interface IVisiter
    {
        //AddCourse
        string AddVisiter(Visiter course);

        //GetCourses
        List<Visiter> GetAllVisiter();

        //GetSingleCourse
        Visiter GetSingleVisiter(long id);

        //UpdateCourse
        string UpdateVisiter(Visiter course);

        //Delete Course
        string RemoveVisiter(int id);

    }
}
