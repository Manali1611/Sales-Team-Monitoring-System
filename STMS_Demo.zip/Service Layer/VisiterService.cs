﻿using DomainLayer.Models;
using RepositoryLayer;
using STMS_Demo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class VisiterService : IVisiter
    {
        private readonly STMSdbContext _dbContext;
        public VisiterService(STMSdbContext dbContext)
        {
            this._dbContext = dbContext;
        }
        
        public string AddVisiter(Visiter course)
        {
            try
            {
                this._dbContext.visiters.Add(course);
                this._dbContext.SaveChanges();
                return "Visiter Added Successfully";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Visiter> GetAllVisiter()
        {
            return this._dbContext.visiters.ToList();
        }

        public Visiter GetSingleVisiter(long id)
        {
            return this._dbContext.visiters.Where(x => x.visitId == id).FirstOrDefault();
        }

        public string RemoveVisiter(int id)
        {
            try
            {
                var C = this._dbContext.visiters.Find(id);
                this._dbContext.Remove(C);
                this._dbContext.SaveChanges();
                return "Visiter Deleted Successfully";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }


        public string UpdateVisiter(Visiter course)
        {
            try
            {
                var C = this._dbContext.visiters.Find(course.visitId);
                if (C != null)
                {
                    C.CustName = course.CustName;
                    C.ContactPerson = course.ContactPerson;
                    C.ContactNo = course.ContactNo;
                    C.InterestProduct = course.InterestProduct;
                    C.VisitSubject = course.VisitSubject;
                    C.Description = course.Description;
                    C.dateTime = course.dateTime;
                    C.IsDisabled = course.IsDisabled;
                    C.IsDeleted = course.IsDeleted;



                    this._dbContext.SaveChanges();
                    return "Course Updated Successfully";
                }
                else
                    return "No Record Found";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
